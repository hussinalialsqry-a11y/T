import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Copy, Lock, Unlock, Trash2, Key } from 'lucide-react';
import { toast } from 'sonner';
import './App.css';

function App() {
  const [encryptText, setEncryptText] = useState('');
  const [encryptKey, setEncryptKey] = useState('');
  const [encryptedResult, setEncryptedResult] = useState('');
  
  const [decryptText, setDecryptText] = useState('');
  const [decryptKey, setDecryptKey] = useState('');
  const [decryptedResult, setDecryptedResult] = useState('');

  // XOR Encryption function (supports Arabic text)
  const xorEncrypt = (text: string, key: string): string => {
    const encoder = new TextEncoder();
    const textBytes = encoder.encode(text);
    
    if (!key) {
      // No key: just encode to base64 directly
      let binary = '';
      for (let i = 0; i < textBytes.length; i++) {
        binary += String.fromCharCode(textBytes[i]);
      }
      return btoa(binary);
    }
    
    const keyBytes = encoder.encode(key);
    const resultBytes = new Uint8Array(textBytes.length);
    
    for (let i = 0; i < textBytes.length; i++) {
      resultBytes[i] = textBytes[i] ^ keyBytes[i % keyBytes.length];
    }
    
    // Convert to base64
    let binary = '';
    for (let i = 0; i < resultBytes.length; i++) {
      binary += String.fromCharCode(resultBytes[i]);
    }
    return btoa(binary);
  };

  // XOR Decryption function (supports Arabic text)
  const xorDecrypt = (text: string, key: string): string => {
    try {
      const binary = atob(text);
      const encryptedBytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        encryptedBytes[i] = binary.charCodeAt(i);
      }
      
      if (!key) {
        // No key: just decode from base64
        const decoder = new TextDecoder('utf-8');
        return decoder.decode(encryptedBytes);
      }
      
      const encoder = new TextEncoder();
      const keyBytes = encoder.encode(key);
      const resultBytes = new Uint8Array(encryptedBytes.length);
      
      for (let i = 0; i < encryptedBytes.length; i++) {
        resultBytes[i] = encryptedBytes[i] ^ keyBytes[i % keyBytes.length];
      }
      
      const decoder = new TextDecoder('utf-8');
      return decoder.decode(resultBytes);
    } catch {
      return 'خطأ: النص المشفر غير صالح';
    }
  };

  const handleEncrypt = () => {
    if (!encryptText.trim()) {
      toast.error('الرجاء إدخال نص للتشفير');
      return;
    }
    const result = xorEncrypt(encryptText, encryptKey);
    setEncryptedResult(result);
    toast.success('تم التشفير بنجاح!');
  };

  const handleDecrypt = () => {
    if (!decryptText.trim()) {
      toast.error('الرجاء إدخال نص مشفر');
      return;
    }
    const result = xorDecrypt(decryptText, decryptKey);
    setDecryptedResult(result);
    if (result.includes('خطأ')) {
      toast.error('فشل فك التشفير');
    } else {
      toast.success('تم فك التشفير بنجاح!');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('تم النسخ إلى الحافظة!');
  };

  const clearAll = () => {
    setEncryptText('');
    setEncryptKey('');
    setEncryptedResult('');
    setDecryptText('');
    setDecryptKey('');
    setDecryptedResult('');
    toast.info('تم مسح جميع الحقول');
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-3xl font-mono font-bold text-gray-800 mb-2">Text Encryptor</h1>
          <p className="text-gray-600 font-mono text-sm">Encrypt / Decrypt Tool</p>
        </div>

        {/* Main Card */}
        <Card className="bg-white border border-gray-300 shadow-sm">
          <CardHeader className="pb-2 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <CardTitle className="text-gray-800 text-lg font-mono">Encryption Tool</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={clearAll}
                className="text-gray-600 border-gray-300 hover:bg-gray-100 font-mono"
              >
                <Trash2 className="w-4 h-4 ml-2" />
                Clear
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <Tabs defaultValue="encrypt" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-gray-100 border border-gray-300 mb-6">
                <TabsTrigger value="encrypt" className="data-[state=active]:bg-gray-800 data-[state=active]:text-white font-mono">
                  <Lock className="w-4 h-4 ml-2" />
                  Encrypt
                </TabsTrigger>
                <TabsTrigger value="decrypt" className="data-[state=active]:bg-gray-800 data-[state=active]:text-white font-mono">
                  <Unlock className="w-4 h-4 ml-2" />
                  Decrypt
                </TabsTrigger>
              </TabsList>

              {/* Encrypt Tab */}
              <TabsContent value="encrypt" className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-700 font-mono flex items-center">
                    <Key className="w-4 h-4 ml-2" />
                    Key (optional)
                  </label>
                  <Input
                    type="password"
                    placeholder="Enter encryption key or leave empty"
                    value={encryptKey}
                    onChange={(e) => setEncryptKey(e.target.value)}
                    className="bg-white border-gray-300 text-gray-800 placeholder:text-gray-400 focus:border-gray-500 font-mono"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm text-gray-700 font-mono">Plain Text</label>
                  <textarea
                    placeholder="Enter text to encrypt..."
                    value={encryptText}
                    onChange={(e) => setEncryptText(e.target.value)}
                    className="w-full min-h-[120px] p-3 rounded-md bg-white border border-gray-300 text-gray-800 placeholder:text-gray-400 focus:border-gray-500 focus:outline-none resize-none font-mono"
                  />
                </div>

                <Button
                  onClick={handleEncrypt}
                  className="w-full bg-gray-800 hover:bg-gray-700 text-white font-mono py-3"
                >
                  <Lock className="w-5 h-5 ml-2" />
                  Encrypt
                </Button>

                {encryptedResult && (
                  <div className="mt-4 p-4 bg-gray-50 rounded border border-gray-300">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-700 font-mono">Encrypted:</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(encryptedResult)}
                        className="text-gray-600 border-gray-300 hover:bg-gray-100 font-mono"
                      >
                        <Copy className="w-4 h-4 ml-2" />
                        Copy
                      </Button>
                    </div>
                    <div className="bg-gray-800 p-3 rounded text-sm text-green-400 font-mono break-all">
                      {encryptedResult}
                    </div>
                  </div>
                )}
              </TabsContent>

              {/* Decrypt Tab */}
              <TabsContent value="decrypt" className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-700 font-mono flex items-center">
                    <Key className="w-4 h-4 ml-2" />
                    Key (if used)
                  </label>
                  <Input
                    type="password"
                    placeholder="Enter decryption key"
                    value={decryptKey}
                    onChange={(e) => setDecryptKey(e.target.value)}
                    className="bg-white border-gray-300 text-gray-800 placeholder:text-gray-400 focus:border-gray-500 font-mono"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm text-gray-700 font-mono">Encrypted Text</label>
                  <textarea
                    placeholder="Enter encrypted text..."
                    value={decryptText}
                    onChange={(e) => setDecryptText(e.target.value)}
                    className="w-full min-h-[120px] p-3 rounded-md bg-white border border-gray-300 text-gray-800 placeholder:text-gray-400 focus:border-gray-500 focus:outline-none resize-none font-mono"
                  />
                </div>

                <Button
                  onClick={handleDecrypt}
                  className="w-full bg-gray-800 hover:bg-gray-700 text-white font-mono py-3"
                >
                  <Unlock className="w-5 h-5 ml-2" />
                  Decrypt
                </Button>

                {decryptedResult && (
                  <div className="mt-4 p-4 bg-gray-50 rounded border border-gray-300">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-700 font-mono">Decrypted:</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(decryptedResult)}
                        className="text-gray-600 border-gray-300 hover:bg-gray-100 font-mono"
                      >
                        <Copy className="w-4 h-4 ml-2" />
                        Copy
                      </Button>
                    </div>
                    <div className={`bg-gray-800 p-3 rounded text-sm font-mono break-all ${decryptedResult.includes('خطأ') ? 'text-red-400' : 'text-green-400'}`}>
                      {decryptedResult}
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-4 text-gray-500 text-xs font-mono">
          <p>All encryption operations are performed locally in your browser.</p>
          <p className="mt-1">No data is sent to any server.</p>
        </div>
      </div>
    </div>
  );
}

export default App;
